import('java.lang.*')
import('java.util.*')
import('com.nx.assist.lua.LuaEngine')
import('com.nx.assist.lua.SQL')
mysql = {}
local _M = mysql

_M.connectSQL = function(host,port,database,user,pass,timeout)
    local success, result = pcall(function()
    	local sql = SQL()
    	if false == sql.connect(host,port,database,user,pass,timeout) then
			sql = nil
		end
        return sql
    end)
    if not success then
    	local errorMessage = result:match(":%d+: (.+)$")
        return nil, errorMessage
    else
        return result,nil
    end
end

_M.executeQuerySQL = function(handle,querySql)
    local success, result = pcall(function()
		ret = handle.executeQuery(querySql)
        return ret
	end)
	if not success then
		local errorMessage = result:match(":%d+: (.+)$")
		return nil, errorMessage
	else
		return result,nil
	end
end

_M.executeSQL = function(handle,querySql)
    local success, result = pcall(function()
		ret = handle.execute(querySql)
		return ret
	end)
	if not success then
		local errorMessage = result:match(":%d+: (.+)$")
		return nil, errorMessage
	else
		return result,nil
	end
end

_M.closeSQL = function(handle)
	if handle ~= nil then
		return handle.disconnect()
    end
end

return _M
